package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.OcrEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEO AI SCANNER PRO", appName)
    }

    @Test
    fun `cleanMessyText formats whitespace and hyphens`() {
        val dirty = "Docu-  \nment   with    extra   spaces"
        val cleaned = OcrEngine.cleanMessyText(dirty)
        assertTrue(cleaned.contains("Document"))
        assertTrue(!cleaned.contains("    "))
    }
}
