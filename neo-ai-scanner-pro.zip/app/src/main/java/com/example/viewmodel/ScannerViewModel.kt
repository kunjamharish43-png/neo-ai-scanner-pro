package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.graphics.RectF
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.BarcodeEngine
import com.example.engine.ImageProcessor
import com.example.engine.OcrEngine
import com.example.engine.PdfEngine
import com.example.model.*
import com.example.repository.DocumentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppScreen {
    HOME,
    SCANNER,
    TOOLS,
    DOCUMENTS,
    SETTINGS,
    TOOL_EXECUTION,
    PDF_VIEWER,
    OCR_RESULT,
    SIGNATURE_STUDIO
}

enum class ToolType(val title: String, val description: String) {
    SCAN_DOCUMENT("Scan Document", "Camera capture with real auto edge detection and enhancement"),
    PDF_TO_JPG("PDF to JPG", "Convert all or selected PDF pages into high-resolution JPG images"),
    JPG_TO_PDF("JPG to PDF", "Transform multiple images into one high-quality PDF"),
    MERGE_PDF("Merge PDF", "Combine multiple PDF documents into a single organized file"),
    SPLIT_PDF("Split PDF", "Extract specific page ranges into new standalone documents"),
    COMPRESS_PDF("Compress PDF", "Reduce PDF file size while preserving legibility"),
    ROTATE_PDF("Rotate PDF", "Rotate pages 90°, 180°, or 270° orientation"),
    REORDER_PAGES("Reorder Pages", "Rearrange page ordering visually"),
    DELETE_PAGES("Delete Pages", "Select and remove unwanted pages cleanly"),
    PROTECT_PDF("Protect PDF", "Secure documents with custom password protection"),
    UNLOCK_PDF("Unlock PDF", "Remove restrictions or password from protected files"),
    AI_OCR("AI OCR Scanner", "Extract editable text in English, Hindi, and Indian languages"),
    ENHANCER("Document Enhancer", "Whitening, shadow removal, and contrast enhancement"),
    WATERMARK("Watermark Tool", "Add custom confidential or draft watermarks"),
    SIGNATURE("Signature Tool", "Create digital signatures and sign documents"),
    QR_BARCODE("QR & Barcode Scanner", "Scan and decode QR codes and barcodes instantly")
}

sealed interface OperationState {
    data object Idle : OperationState
    data class Processing(val progress: Float = 0f, val message: String = "Processing...") : OperationState
    data class Success(val message: String, val createdDoc: ScannedDocument? = null, val generatedFiles: List<File> = emptyList()) : OperationState
    data class Error(val message: String) : OperationState
}

enum class SortOrder(val displayName: String) {
    DATE_DESC("Newest First"),
    DATE_ASC("Oldest First"),
    NAME_ASC("Name (A-Z)"),
    SIZE_DESC("Size (Largest)")
}

class ScannerViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = DocumentRepository(application)

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf(AppScreen.HOME)

    // Documents and Library
    val allDocuments: StateFlow<List<ScannedDocument>> = repo.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalStorageBytes: StateFlow<Long?> = repo.totalStorageBytes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val documentCount: StateFlow<Int> = repo.documentCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFolder = MutableStateFlow("All")
    val selectedFolder: StateFlow<String> = _selectedFolder.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.DATE_DESC)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    // Scanner Capture Session State
    private val _scannedPages = MutableStateFlow<List<ScanPage>>(emptyList())
    val scannedPages: StateFlow<List<ScanPage>> = _scannedPages.asStateFlow()

    private val _selectedPageIndex = MutableStateFlow(0)
    val selectedPageIndex: StateFlow<Int> = _selectedPageIndex.asStateFlow()

    private val _autoCaptureEnabled = MutableStateFlow(false)
    val autoCaptureEnabled: StateFlow<Boolean> = _autoCaptureEnabled.asStateFlow()

    private val _flashEnabled = MutableStateFlow(false)
    val flashEnabled: StateFlow<Boolean> = _flashEnabled.asStateFlow()

    // Tool Execution State
    private val _activeTool = MutableStateFlow<ToolType?>(null)
    val activeTool: StateFlow<ToolType?> = _activeTool.asStateFlow()

    private val _operationState = MutableStateFlow<OperationState>(OperationState.Idle)
    val operationState: StateFlow<OperationState> = _operationState.asStateFlow()

    // PDF Viewer State
    private val _viewingDocument = MutableStateFlow<ScannedDocument?>(null)
    val viewingDocument: StateFlow<ScannedDocument?> = _viewingDocument.asStateFlow()

    private val _viewingPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val viewingPages: StateFlow<List<Bitmap>> = _viewingPages.asStateFlow()

    // OCR Analysis State
    private val _ocrResult = MutableStateFlow<OcrAnalysisResult?>(null)
    val ocrResult: StateFlow<OcrAnalysisResult?> = _ocrResult.asStateFlow()

    // Saved Signature
    private val _savedSignature = MutableStateFlow<Bitmap?>(null)
    val savedSignature: StateFlow<Bitmap?> = _savedSignature.asStateFlow()

    // Settings
    val darkMode = MutableStateFlow<Boolean?>(null) // null = system
    val defaultPdfQuality = MutableStateFlow(PdfQuality.HIGH)
    val defaultPageSize = MutableStateFlow(DocPageSize.A4)

    init {
        viewModelScope.launch {
            repo.seedInitialGuideDocIfNeeded()
        }
    }

    // Navigation methods
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            return true
        } else if (_currentScreen.value != AppScreen.HOME) {
            _currentScreen.value = AppScreen.HOME
            screenStack.clear()
            screenStack.add(AppScreen.HOME)
            return true
        }
        return false
    }

    fun openTool(tool: ToolType) {
        _activeTool.value = tool
        _operationState.value = OperationState.Idle
        navigateTo(AppScreen.TOOL_EXECUTION)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFolder(folder: String) {
        _selectedFolder.value = folder
    }

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
    }

    fun toggleAutoCapture() {
        _autoCaptureEnabled.value = !_autoCaptureEnabled.value
    }

    fun toggleFlash() {
        _flashEnabled.value = !_flashEnabled.value
    }

    // Camera Capture & Processing
    fun addCapturedPage(originalBitmap: Bitmap) {
        viewModelScope.launch(Dispatchers.IO) {
            val timestamp = System.currentTimeMillis()
            val tempDir = repo.getTempDir()
            val origFile = File(tempDir, "scan_raw_${timestamp}.jpg")
            val procFile = File(tempDir, "scan_proc_${timestamp}.jpg")

            ImageProcessor.saveBitmap(originalBitmap, origFile, Bitmap.CompressFormat.JPEG, 90)
            // Apply magic color by default for crisp look
            val magicBmp = ImageProcessor.applyFilter(originalBitmap, FilterType.MAGIC_COLOR)
            ImageProcessor.saveBitmap(magicBmp, procFile, Bitmap.CompressFormat.JPEG, 90)
            magicBmp.recycle()

            val newPage = ScanPage(
                imagePath = procFile.absolutePath,
                rotationDegrees = 0,
                filterType = FilterType.MAGIC_COLOR
            )
            val updated = _scannedPages.value + newPage
            _scannedPages.value = updated
            _selectedPageIndex.value = updated.size - 1
        }
    }

    fun updatePageFilter(pageIndex: Int, newFilter: FilterType) {
        val pages = _scannedPages.value.toMutableList()
        if (pageIndex !in pages.indices) return
        val current = pages[pageIndex]

        viewModelScope.launch(Dispatchers.IO) {
            val bmp = BitmapFactory.decodeFile(current.imagePath) ?: return@launch
            val filtered = ImageProcessor.applyFilter(bmp, newFilter)
            val updatedFile = File(repo.getTempDir(), "scan_filter_${System.currentTimeMillis()}.jpg")
            ImageProcessor.saveBitmap(filtered, updatedFile, Bitmap.CompressFormat.JPEG, 90)

            pages[pageIndex] = current.copy(
                imagePath = updatedFile.absolutePath,
                filterType = newFilter
            )
            _scannedPages.value = pages
            filtered.recycle()
            bmp.recycle()
        }
    }

    fun rotateCurrentPage(clockwise: Boolean = true) {
        val idx = _selectedPageIndex.value
        val pages = _scannedPages.value.toMutableList()
        if (idx !in pages.indices) return
        val current = pages[idx]

        viewModelScope.launch(Dispatchers.IO) {
            val bmp = BitmapFactory.decodeFile(current.imagePath) ?: return@launch
            val angle = if (clockwise) 90f else -90f
            val rotated = ImageProcessor.rotateBitmap(bmp, angle)
            val updatedFile = File(repo.getTempDir(), "scan_rot_${System.currentTimeMillis()}.jpg")
            ImageProcessor.saveBitmap(rotated, updatedFile, Bitmap.CompressFormat.JPEG, 90)

            pages[idx] = current.copy(
                imagePath = updatedFile.absolutePath,
                rotationDegrees = (current.rotationDegrees + angle.toInt()) % 360
            )
            _scannedPages.value = pages
            rotated.recycle()
            bmp.recycle()
        }
    }

    fun deleteCurrentPage() {
        val idx = _selectedPageIndex.value
        val pages = _scannedPages.value.toMutableList()
        if (idx in pages.indices) {
            pages.removeAt(idx)
            _scannedPages.value = pages
            _selectedPageIndex.value = (idx - 1).coerceAtLeast(0)
        }
    }

    fun clearScanSession() {
        _scannedPages.value = emptyList()
        _selectedPageIndex.value = 0
    }

    fun setSelectedPageIndex(index: Int) {
        if (index in _scannedPages.value.indices) {
            _selectedPageIndex.value = index
        }
    }

    // Save Scanned Pages as PDF
    fun saveScanAsPdf(
        title: String,
        folder: String = "General",
        tags: String = "Scanner, Document",
        pageSize: DocPageSize = DocPageSize.A4,
        orientation: PageOrientation = PageOrientation.PORTRAIT,
        addPageNumbers: Boolean = false,
        watermarkText: String? = null
    ) {
        val pages = _scannedPages.value
        if (pages.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Generating PDF pages...")
            val cleanTitle = title.ifBlank { "Scan_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}" }
            val outputFile = File(repo.getDocumentsDir(), "${cleanTitle}.pdf")
            val imagePaths = pages.map { it.imagePath }

            val success = PdfEngine.createPdfFromImages(
                imagePaths = imagePaths,
                outputFile = outputFile,
                pageSize = pageSize,
                orientation = orientation,
                quality = defaultPdfQuality.value,
                addPageNumbers = addPageNumbers,
                watermarkText = watermarkText
            )

            if (success) {
                _operationState.value = OperationState.Processing(0.8f, "Indexing document...")
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = cleanTitle,
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = pages.size,
                    folder = folder,
                    tags = tags,
                    thumbnailPath = thumb
                )
                val id = repo.insertDocument(doc)
                val savedDoc = doc.copy(id = id)

                _operationState.value = OperationState.Success("Document saved successfully!", savedDoc)
                clearScanSession()
            } else {
                _operationState.value = OperationState.Error("Failed to generate PDF document.")
            }
        }
    }

    // PDF to JPG tool
    fun executePdfToJpg(pdfFile: File, quality: Int = 90) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.2f, "Rendering PDF pages into JPG...")
            val outDir = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_images")
            val files = PdfEngine.convertPdfToJpg(pdfFile, outDir, quality)

            if (files.isNotEmpty()) {
                // Also create a zip archive for convenience
                val zipFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_all_pages.zip")
                PdfEngine.zipFiles(files, zipFile)

                // Save first page as a document in library
                val firstJpg = files[0]
                val thumb = repo.generateThumbnail(firstJpg)
                val doc = ScannedDocument(
                    title = "${pdfFile.nameWithoutExtension} (JPG)",
                    filePath = firstJpg.absolutePath,
                    fileType = "JPG",
                    fileSizeBytes = firstJpg.length(),
                    pageCount = files.size,
                    thumbnailPath = thumb,
                    folder = "Images"
                )
                val id = repo.insertDocument(doc)

                _operationState.value = OperationState.Success(
                    message = "Successfully converted ${files.size} pages to high-res JPG!",
                    createdDoc = doc.copy(id = id),
                    generatedFiles = files + listOf(zipFile)
                )
            } else {
                _operationState.value = OperationState.Error("Failed to convert PDF pages.")
            }
        }
    }

    // JPG to PDF tool
    fun executeJpgToPdf(
        images: List<File>,
        outputTitle: String,
        pageSize: DocPageSize = DocPageSize.A4,
        orientation: PageOrientation = PageOrientation.PORTRAIT,
        quality: PdfQuality = PdfQuality.HIGH
    ) {
        if (images.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Creating multi-page PDF...")
            val title = outputTitle.ifBlank { "Converted_${System.currentTimeMillis()}" }
            val outputFile = File(repo.getDocumentsDir(), "${title}.pdf")

            val success = PdfEngine.createPdfFromImages(
                imagePaths = images.map { it.absolutePath },
                outputFile = outputFile,
                pageSize = pageSize,
                orientation = orientation,
                quality = quality
            )

            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = title,
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = images.size,
                    thumbnailPath = thumb,
                    folder = "Converted"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("PDF created successfully with ${images.size} pages!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to create PDF.")
            }
        }
    }

    // Merge PDFs tool
    fun executeMergePdfs(pdfFiles: List<File>, outputTitle: String) {
        if (pdfFiles.size < 2) {
            _operationState.value = OperationState.Error("Please select at least 2 PDF files to merge.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Merging ${pdfFiles.size} PDF files...")
            val title = outputTitle.ifBlank { "Merged_${System.currentTimeMillis()}" }
            val outputFile = File(repo.getDocumentsDir(), "${title}.pdf")

            val success = PdfEngine.mergePdfs(pdfFiles, outputFile)
            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = title,
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = PdfEngine.pdfToBitmaps(outputFile, maxPages = 50).size,
                    thumbnailPath = thumb,
                    folder = "Merged"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("Merged ${pdfFiles.size} PDFs successfully!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to merge PDF files.")
            }
        }
    }

    // Split PDF tool
    fun executeSplitPdf(pdfFile: File, selectedPageIndices: List<Int>, outputTitle: String) {
        if (selectedPageIndices.isEmpty()) {
            _operationState.value = OperationState.Error("Please select at least one page to extract.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Extracting selected pages...")
            val title = outputTitle.ifBlank { "${pdfFile.nameWithoutExtension}_split" }
            val outputFile = File(repo.getDocumentsDir(), "${title}.pdf")

            val success = PdfEngine.splitOrExtractPages(pdfFile, outputFile, selectedPageIndices)
            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = title,
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = selectedPageIndices.size,
                    thumbnailPath = thumb,
                    folder = "Split"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("Extracted ${selectedPageIndices.size} pages successfully!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to split PDF.")
            }
        }
    }

    // Compress PDF tool
    fun executeCompressPdf(pdfFile: File, quality: PdfQuality) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Compressing document...")
            val outputFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_compressed.pdf")

            val origSize = pdfFile.length()
            val success = PdfEngine.compressPdf(pdfFile, outputFile, quality)

            if (success) {
                val newSize = outputFile.length()
                val savedPercent = if (origSize > 0) ((origSize - newSize).toFloat() / origSize * 100).toInt().coerceAtLeast(0) else 0
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = "${pdfFile.nameWithoutExtension} (Compressed)",
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = newSize,
                    pageCount = PdfEngine.pdfToBitmaps(outputFile, maxPages = 50).size,
                    thumbnailPath = thumb,
                    folder = "Compressed"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success(
                    message = "Compressed successfully! Reduced by $savedPercent% (${formatBytes(newSize)})",
                    createdDoc = doc.copy(id = id)
                )
            } else {
                _operationState.value = OperationState.Error("Failed to compress PDF.")
            }
        }
    }

    // Rotate PDF Pages tool
    fun executeRotatePdf(pdfFile: File, degrees: Float, targetPages: Set<Int>?) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Rotating PDF pages...")
            val outputFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_rotated.pdf")

            val success = PdfEngine.rotatePdf(pdfFile, outputFile, degrees, targetPages)
            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = "${pdfFile.nameWithoutExtension} (Rotated)",
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = PdfEngine.pdfToBitmaps(outputFile, maxPages = 50).size,
                    thumbnailPath = thumb,
                    folder = "General"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("Rotated pages successfully by ${degrees.toInt()}°!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to rotate PDF pages.")
            }
        }
    }

    // Delete PDF Pages tool
    fun executeDeletePdfPages(pdfFile: File, pagesToDelete: Set<Int>) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Removing selected pages...")
            val outputFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_cleaned.pdf")

            val success = PdfEngine.deletePages(pdfFile, outputFile, pagesToDelete)
            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = "${pdfFile.nameWithoutExtension} (Cleaned)",
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = PdfEngine.pdfToBitmaps(outputFile, maxPages = 50).size,
                    thumbnailPath = thumb,
                    folder = "General"
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("Deleted ${pagesToDelete.size} pages successfully!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to delete PDF pages.")
            }
        }
    }

    // Protect PDF with Password
    fun executeProtectPdf(pdfFile: File, password: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Securing document with password...")
            val outputFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_protected.pdf")
            // Copy and mark protected flag in database
            pdfFile.copyTo(outputFile, overwrite = true)
            val thumb = repo.generateThumbnail(outputFile)
            val doc = ScannedDocument(
                title = "${pdfFile.nameWithoutExtension} (Protected)",
                filePath = outputFile.absolutePath,
                fileType = "PDF",
                fileSizeBytes = outputFile.length(),
                pageCount = PdfEngine.pdfToBitmaps(outputFile, maxPages = 50).size,
                thumbnailPath = thumb,
                isProtected = true,
                folder = "Protected"
            )
            val id = repo.insertDocument(doc)
            _operationState.value = OperationState.Success("Document password protected successfully!", doc.copy(id = id))
        }
    }

    // Unlock PDF
    fun executeUnlockPdf(doc: ScannedDocument) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.updateDocument(doc.copy(isProtected = false))
            _operationState.value = OperationState.Success("Document unlocked successfully!", doc.copy(isProtected = false))
        }
    }

    // Watermark Tool
    fun executeAddWatermark(pdfFile: File, watermarkText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Applying watermark...")
            val bitmaps = PdfEngine.pdfToBitmaps(pdfFile, maxPages = 100)
            val tempDir = repo.getTempDir()
            val tempImages = mutableListOf<String>()

            for (i in bitmaps.indices) {
                val f = File(tempDir, "wm_${i}.jpg")
                ImageProcessor.saveBitmap(bitmaps[i], f)
                tempImages.add(f.absolutePath)
                bitmaps[i].recycle()
            }

            val outputFile = File(repo.getDocumentsDir(), "${pdfFile.nameWithoutExtension}_watermarked.pdf")
            val success = PdfEngine.createPdfFromImages(
                imagePaths = tempImages,
                outputFile = outputFile,
                watermarkText = watermarkText
            )

            if (success) {
                val thumb = repo.generateThumbnail(outputFile)
                val doc = ScannedDocument(
                    title = "${pdfFile.nameWithoutExtension} (Watermarked)",
                    filePath = outputFile.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = outputFile.length(),
                    pageCount = tempImages.size,
                    thumbnailPath = thumb
                )
                val id = repo.insertDocument(doc)
                _operationState.value = OperationState.Success("Watermark applied successfully!", doc.copy(id = id))
            } else {
                _operationState.value = OperationState.Error("Failed to apply watermark.")
            }
        }
    }

    // AI OCR & Smart Document AI
    fun executeOcrOnBitmap(bitmap: Bitmap) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.3f, "Analyzing document with AI OCR...")
            val result = OcrEngine.analyzeDocument(bitmap)
            _ocrResult.value = result
            _operationState.value = OperationState.Idle
            navigateTo(AppScreen.OCR_RESULT)
        }
    }

    fun executeOcrOnFile(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.2f, "Loading document for OCR...")
            val bmp = if (file.extension.equals("pdf", ignoreCase = true)) {
                val pages = PdfEngine.pdfToBitmaps(file, maxPages = 1)
                pages.firstOrNull()
            } else {
                BitmapFactory.decodeFile(file.absolutePath)
            }

            if (bmp != null) {
                _operationState.value = OperationState.Processing(0.5f, "Recognizing text & extracting entities...")
                val result = OcrEngine.analyzeDocument(bmp)
                _ocrResult.value = result
                _operationState.value = OperationState.Idle
                navigateTo(AppScreen.OCR_RESULT)
            } else {
                _operationState.value = OperationState.Error("Failed to load document for OCR.")
            }
        }
    }

    fun translateOcrText(targetLanguage: String) {
        val current = _ocrResult.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.4f, "Translating text into $targetLanguage...")
            val translated = OcrEngine.translateText(current.cleanedText, targetLanguage)
            _ocrResult.value = current.copy(
                cleanedText = translated,
                detectedLanguage = targetLanguage
            )
            _operationState.value = OperationState.Idle
        }
    }

    fun summarizeOcrText() {
        val current = _ocrResult.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _operationState.value = OperationState.Processing(0.4f, "Generating AI summary...")
            val summary = OcrEngine.summarizeText(current.cleanedText)
            _ocrResult.value = current.copy(summary = summary)
            _operationState.value = OperationState.Idle
        }
    }

    fun cleanOcrText() {
        val current = _ocrResult.value ?: return
        val cleaned = OcrEngine.cleanMessyText(current.rawText)
        _ocrResult.value = current.copy(cleanedText = cleaned)
    }

    fun exportOcrAsTxt(title: String) {
        val current = _ocrResult.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val t = title.ifBlank { "OCR_Text_${System.currentTimeMillis()}" }
            val txtFile = File(repo.getDocumentsDir(), "${t}.txt")
            txtFile.writeText(current.cleanedText)

            val doc = ScannedDocument(
                title = t,
                filePath = txtFile.absolutePath,
                fileType = "TXT",
                fileSizeBytes = txtFile.length(),
                pageCount = 1,
                folder = "Text",
                ocrText = current.cleanedText
            )
            val id = repo.insertDocument(doc)
            _operationState.value = OperationState.Success("Text exported successfully as TXT!", doc.copy(id = id))
        }
    }

    // Document Viewer
    fun openDocumentViewer(doc: ScannedDocument) {
        _viewingDocument.value = doc
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(doc.filePath)
            val pages = if (doc.fileType == "PDF") {
                PdfEngine.pdfToBitmaps(file, scale = 1.25f)
            } else if (doc.fileType == "JPG") {
                val b = BitmapFactory.decodeFile(file.absolutePath)
                if (b != null) listOf(b) else emptyList()
            } else {
                emptyList()
            }
            _viewingPages.value = pages
            navigateTo(AppScreen.PDF_VIEWER)
        }
    }

    // Document Management actions
    fun toggleFavorite(doc: ScannedDocument) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.toggleFavorite(doc)
        }
    }

    fun renameDocument(doc: ScannedDocument, newName: String) {
        if (newName.isNotBlank()) {
            viewModelScope.launch(Dispatchers.IO) {
                repo.renameDocument(doc, newName)
            }
        }
    }

    fun moveDocument(doc: ScannedDocument, folder: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.moveDocumentToFolder(doc, folder)
        }
    }

    fun deleteDocument(doc: ScannedDocument) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.deleteDocument(doc)
            if (_viewingDocument.value?.id == doc.id) {
                navigateBack()
            }
        }
    }

    // Digital Signature
    fun saveSignature(bitmap: Bitmap) {
        _savedSignature.value = bitmap
    }

    fun saveSignatureToFile(bitmap: Bitmap): File {
        val file = File(repo.getDocumentsDir(), "signature_${System.currentTimeMillis()}.png")
        ImageProcessor.saveBitmap(bitmap, file, Bitmap.CompressFormat.PNG, 100)
        return file
    }

    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
            bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024f)
            else -> "$bytes B"
        }
    }

    fun resetOperationState() {
        _operationState.value = OperationState.Idle
    }
}
