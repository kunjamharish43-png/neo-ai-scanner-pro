package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ScannedDocument
import com.example.ui.components.NeoTopBar
import com.example.ui.theme.*
import com.example.viewmodel.ScannerViewModel

data class DrawPoint(val x: Float, val y: Float)

@Composable
fun SignatureScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val paths = remember { mutableStateListOf<Pair<androidx.compose.ui.graphics.Path, Color>>() }
    var currentPath by remember { mutableStateOf<androidx.compose.ui.graphics.Path?>(null) }

    var selectedColor by remember { mutableStateOf(Color(0xFF0A1E3F)) }
    var strokeWidth by remember { mutableStateOf(6f) }

    val inkColors = listOf(
        Color(0xFF0A1E3F), // Black/Navy
        Color(0xFF0066FF), // Royal Blue
        Color(0xFFDC2626)  // Crimson
    )

    Scaffold(
        topBar = {
            NeoTopBar(
                title = "Digital Signature Studio",
                canNavigateBack = true,
                onNavigateBack = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.testTag("signature_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Instructions Card
            Text(
                text = "Draw your signature inside the box using your finger or stylus:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Drawing Canvas Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(2.dp, PrimaryBlue.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    .testTag("signature_drawing_canvas")
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(selectedColor, strokeWidth) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        val p = androidx.compose.ui.graphics.Path().apply {
                                            moveTo(offset.x, offset.y)
                                        }
                                        currentPath = p
                                        paths.add(p to selectedColor)
                                    },
                                    onDrag = { change, _ ->
                                        currentPath?.lineTo(change.position.x, change.position.y)
                                        // Trigger recompose
                                        if (paths.isNotEmpty()) {
                                            val last = paths.last()
                                            paths[paths.lastIndex] = last
                                        }
                                    },
                                    onDragEnd = {
                                        currentPath = null
                                    }
                                )
                            }
                    ) {
                        for ((path, color) in paths) {
                            drawPath(
                                path = path,
                                color = color,
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }

                    // Baseline guide
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth(0.85f)
                            .padding(bottom = 40.dp)
                            .height(1.dp)
                            .background(Color.LightGray)
                    )
                    Text(
                        text = "Sign on the line",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 20.dp)
                    )
                }
            }

            // Controls Row (Color & Width)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Color Picker
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    inkColors.forEach { color ->
                        val isSelected = selectedColor == color
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) AccentCyan else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColor = color }
                        )
                    }
                }

                // Stroke width buttons
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(4f to "Fine", 7f to "Medium", 11f to "Bold").forEach { (w, label) ->
                        val isSelected = strokeWidth == w
                        FilterChip(
                            selected = isSelected,
                            onClick = { strokeWidth = w },
                            label = { Text(label) }
                        )
                    }
                }
            }

            // Bottom Actions (Clear & Save)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { paths.clear() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("clear_signature_button")
                ) {
                    Icon(Icons.Default.Clear, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear")
                }

                Button(
                    onClick = {
                        if (paths.isEmpty()) {
                            Toast.makeText(context, "Please sign on the canvas first", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        // Render canvas paths to transparent Bitmap
                        val bmp = Bitmap.createBitmap(800, 400, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bmp)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            style = Paint.Style.STROKE
                            strokeCap = Paint.Cap.ROUND
                            strokeJoin = Paint.Join.ROUND
                        }

                        for ((p, c) in paths) {
                            paint.color = c.toArgb()
                            paint.strokeWidth = strokeWidth * 2f
                            canvas.drawPath(p.asAndroidPath(), paint)
                        }

                        viewModel.saveSignature(bmp)
                        val file = viewModel.saveSignatureToFile(bmp)
                        Toast.makeText(context, "Signature saved to device!", Toast.LENGTH_SHORT).show()
                        viewModel.navigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1.3f).height(48.dp).testTag("save_signature_button")
                ) {
                    Icon(Icons.Default.Done, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Signature")
                }
            }
        }
    }
}
