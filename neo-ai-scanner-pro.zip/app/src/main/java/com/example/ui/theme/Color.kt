package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Navy Brand
val DeepNavy900 = Color(0xFF071228)
val DeepNavy800 = Color(0xFF0A1E3F)
val DeepNavy700 = Color(0xFF0F2E5E)
val PrimaryBlue = Color(0xFF0066FF)
val PrimaryBlueVariant = Color(0xFF0052CC)
val AccentCyan = Color(0xFF00D2FF)
val ElectricBlue = Color(0xFF38BDF8)

// Neutral & Backgrounds - Light
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDF2F7)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

// Neutral & Backgrounds - Dark
val DarkBackground = Color(0xFF070D18)
val DarkSurface = Color(0xFF0F1B2F)
val DarkSurfaceVariant = Color(0xFF16253D)
val DarkBorder = Color(0xFF1E3252)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Functional Status Colors
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val PurpleAccent = Color(0xFF8B5CF6)
