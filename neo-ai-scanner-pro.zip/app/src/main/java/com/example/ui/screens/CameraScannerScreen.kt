package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.example.model.DocPageSize
import com.example.model.FilterType
import com.example.model.PageOrientation
import com.example.ui.components.OperationProgressDialog
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.OperationState
import com.example.viewmodel.ScannerViewModel
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScannerScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scannedPages by viewModel.scannedPages.collectAsState()
    val selectedPageIndex by viewModel.selectedPageIndex.collectAsState()
    val autoCapture by viewModel.autoCaptureEnabled.collectAsState()
    val flashEnabled by viewModel.flashEnabled.collectAsState()
    val opState by viewModel.operationState.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var camera: Camera? by remember { mutableStateOf(null) }
    var showReviewModal by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }

    // Save dialog form state
    var docTitle by remember { mutableStateOf("Scan_${System.currentTimeMillis() / 1000}") }
    var selectedPageSize by remember { mutableStateOf(DocPageSize.A4) }
    var selectedOrientation by remember { mutableStateOf(PageOrientation.PORTRAIT) }
    var addPageNumbers by remember { mutableStateOf(true) }
    var watermarkText by remember { mutableStateOf("") }

    // Photo picker fallback / import
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            try {
                val input = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(input)
                if (bmp != null) {
                    viewModel.addCapturedPage(bmp)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Auto-scan timer simulation
    var isStable by remember { mutableStateOf(false) }
    LaunchedEffect(autoCapture, hasCameraPermission) {
        if (autoCapture && hasCameraPermission) {
            kotlinx.coroutines.delay(2000)
            isStable = true
        } else {
            isStable = false
        }
    }

    if (!hasCameraPermission) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(DeepNavy900)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CameraAlt,
                contentDescription = null,
                tint = AccentCyan,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Camera Permission Required",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "NEO AI SCANNER PRO requires camera access to scan documents, detect edges, and capture pages in real time.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(0.8f).height(48.dp).testTag("grant_camera_permission_button")
            ) {
                Text("Grant Camera Permission")
            }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = { galleryLauncher.launch("image/*") },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(0.8f).height(48.dp).testTag("import_gallery_fallback_button")
            ) {
                Text("Import from Gallery Instead")
            }
        }
        return
    }

    // Live Camera Scanner UI
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("camera_scanner_screen")
    ) {
        // Camera Preview
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val capture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()
                        imageCapture = capture

                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                        cameraProvider.unbindAll()
                        camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            capture
                        )
                    } catch (e: Exception) {
                        Log.e("CameraScanner", "Camera binding failed", e)
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Viewfinder Guide Overlay with Animated Scan Line
        val infiniteTransition = rememberInfiniteTransition(label = "scan_beam")
        val scanOffsetY by infiniteTransition.animateFloat(
            initialValue = 0.15f,
            targetValue = 0.75f,
            animationSpec = infiniteRepeatable(
                animation = tween(2200, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "laser_y"
        )

        // Document framing rectangle overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 84.dp)
        ) {
            // Viewfinder border with cyan corner accents
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            ) {
                // Animated laser beam line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.005f)
                        .offset(y = (scanOffsetY * 500).dp)
                        .background(AccentCyan.copy(alpha = 0.85f))
                )

                // Corner brackets
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .size(24.dp)
                        .border(3.dp, AccentCyan, RoundedCornerShape(topStart = 16.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(24.dp)
                        .border(3.dp, AccentCyan, RoundedCornerShape(topEnd = 16.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .size(24.dp)
                        .border(3.dp, AccentCyan, RoundedCornerShape(bottomStart = 16.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                        .border(3.dp, AccentCyan, RoundedCornerShape(bottomEnd = 16.dp))
                )
            }
        }

        // Top Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier
                    .size(44.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .testTag("camera_back_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }

            // Auto-Capture Toggle
            Surface(
                color = if (autoCapture) AccentCyan.copy(alpha = 0.3f) else Color.Black.copy(alpha = 0.5f),
                shape = RoundedCornerShape(20.dp),
                border = if (autoCapture) androidx.compose.foundation.BorderStroke(1.dp, AccentCyan) else null,
                modifier = Modifier.clickable { viewModel.toggleAutoCapture() }.testTag("auto_capture_toggle")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (autoCapture) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (autoCapture) AccentCyan else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (autoCapture) "Auto Capture ON" else "Manual Capture",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }

            // Flash Toggle
            IconButton(
                onClick = {
                    viewModel.toggleFlash()
                    camera?.cameraControl?.enableTorch(!flashEnabled)
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .testTag("camera_flash_toggle")
            ) {
                Icon(
                    imageVector = if (flashEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    contentDescription = "Flash",
                    tint = if (flashEnabled) WarningAmber else Color.White
                )
            }
        }

        // Center Instruction
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp)
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = if (autoCapture && isStable) "Hold steady... Document detected" else "Align document inside frame",
                style = MaterialTheme.typography.labelMedium,
                color = if (isStable) AccentCyan else Color.White
            )
        }

        // Bottom Controls Overlay
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Scanned Pages Tray preview if any pages are scanned
            if (scannedPages.isNotEmpty()) {
                Surface(
                    color = Color.Black.copy(alpha = 0.75f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clickable { showReviewModal = true }
                        .testTag("scanned_pages_tray")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${scannedPages.size} ${if (scannedPages.size == 1) "Page" else "Pages"} Scanned",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Edit, contentDescription = "Review", tint = AccentCyan, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Main Action Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gallery Import
                IconButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    modifier = Modifier
                        .size(52.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .testTag("camera_import_gallery")
                ) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Import", tint = Color.White)
                }

                // Shutter Button
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(PrimaryBlue)
                        .clickable {
                            val executor = Executors.newSingleThreadExecutor()
                            val tempFile = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                            val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

                            imageCapture?.takePicture(
                                outputOptions,
                                executor,
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        val bmp = BitmapFactory.decodeFile(tempFile.absolutePath)
                                        if (bmp != null) {
                                            viewModel.addCapturedPage(bmp)
                                        }
                                    }
                                    override fun onError(exception: ImageCaptureException) {
                                        Log.e("CameraScanner", "Photo capture failed", exception)
                                    }
                                }
                            )
                        }
                        .testTag("camera_shutter_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Capture", tint = Color.White, modifier = Modifier.size(30.dp))
                }

                // Done & Review Button
                if (scannedPages.isNotEmpty()) {
                    Button(
                        onClick = { showReviewModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = DeepNavy900),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(48.dp).testTag("camera_done_review_button")
                    ) {
                        Text("Review (${scannedPages.size})", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.size(52.dp))
                }
            }
        }
    }

    // Modal Sheet for Reviewing & Enhancing Pages
    if (showReviewModal && scannedPages.isNotEmpty()) {
        val currentPage = scannedPages.getOrNull(selectedPageIndex) ?: scannedPages.first()

        ModalBottomSheet(
            onDismissRequest = { showReviewModal = false },
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.testTag("page_review_modal")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Page ${selectedPageIndex + 1} of ${scannedPages.size}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row {
                        IconButton(
                            onClick = { viewModel.rotateCurrentPage() },
                            modifier = Modifier.testTag("review_rotate_button")
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(
                            onClick = {
                                viewModel.deleteCurrentPage()
                                if (scannedPages.size <= 1) showReviewModal = false
                            },
                            modifier = Modifier.testTag("review_delete_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Page", tint = DangerRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Page Preview
                Box(
                    modifier = Modifier
                        .height(300.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(File(currentPage.imagePath)),
                        contentDescription = "Page Preview",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Filters Row
                Text(
                    text = "Document Filters",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(FilterType.entries) { filter ->
                        val isSelected = currentPage.filterType == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updatePageFilter(selectedPageIndex, filter) },
                            label = { Text(filter.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom actions: Add more pages or Save as PDF
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showReviewModal = false },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("add_more_pages_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Page")
                    }

                    Button(
                        onClick = {
                            showReviewModal = false
                            showSaveDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1.3f).height(48.dp).testTag("save_scanned_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save as PDF")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Save as PDF Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Document as PDF") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("Document Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("save_title_input")
                    )

                    // Page size selector
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Page Format:", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(DocPageSize.A4, DocPageSize.LETTER, DocPageSize.AUTO).forEach { size ->
                                val isSel = selectedPageSize == size
                                Surface(
                                    color = if (isSel) PrimaryBlue else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.clickable { selectedPageSize = size }
                                ) {
                                    Text(
                                        text = size.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Watermark Input
                    OutlinedTextField(
                        value = watermarkText,
                        onValueChange = { watermarkText = it },
                        label = { Text("Watermark (Optional)") },
                        placeholder = { Text("e.g. CONFIDENTIAL / DRAFT") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Page Numbering Checkbox
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { addPageNumbers = !addPageNumbers }
                    ) {
                        Checkbox(checked = addPageNumbers, onCheckedChange = { addPageNumbers = it })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Page Numbers (e.g. 1/3)", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSaveDialog = false
                        viewModel.saveScanAsPdf(
                            title = docTitle,
                            pageSize = selectedPageSize,
                            orientation = selectedOrientation,
                            addPageNumbers = addPageNumbers,
                            watermarkText = watermarkText.ifBlank { null }
                        )
                    },
                    modifier = Modifier.testTag("save_pdf_confirm_button")
                ) {
                    Text("Save Document")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Progress Dialog during PDF generation
    if (opState is OperationState.Processing) {
        val proc = opState as OperationState.Processing
        OperationProgressDialog(message = proc.message, progress = proc.progress)
    }

    if (opState is OperationState.Success) {
        val succ = opState as OperationState.Success
        AlertDialog(
            onDismissRequest = { viewModel.resetOperationState() },
            title = { Text("Success!") },
            text = { Text(succ.message) },
            confirmButton = {
                Button(
                    onClick = {
                        val doc = succ.createdDoc
                        viewModel.resetOperationState()
                        if (doc != null) {
                            viewModel.openDocumentViewer(doc)
                        } else {
                            viewModel.navigateTo(AppScreen.HOME)
                        }
                    },
                    modifier = Modifier.testTag("success_open_button")
                ) {
                    Text("Open Document")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    viewModel.resetOperationState()
                    viewModel.navigateTo(AppScreen.HOME)
                }) {
                    Text("Done")
                }
            }
        )
    }
}
