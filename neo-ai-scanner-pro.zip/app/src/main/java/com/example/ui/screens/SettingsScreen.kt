package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DocPageSize
import com.example.model.PdfQuality
import com.example.ui.components.NeoTopBar
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.PrimaryBlue
import com.example.viewmodel.ScannerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val storageBytes by viewModel.totalStorageBytes.collectAsState()
    val defaultQuality by viewModel.defaultPdfQuality.collectAsState()
    val defaultPageSize by viewModel.defaultPageSize.collectAsState()
    val isDark by viewModel.darkMode.collectAsState()

    var showQualityDialog by remember { mutableStateOf(false) }
    var showPageSizeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            NeoTopBar(title = "Settings & Preferences")
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.testTag("settings_screen")
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Appearance Section
            item {
                SettingsSectionHeader("Appearance & Display")
            }
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.DarkMode,
                            title = "Theme",
                            subtitle = when (isDark) {
                                true -> "Dark Mode"
                                false -> "Light Mode"
                                null -> "System Default"
                            },
                            onClick = {
                                viewModel.darkMode.value = when (isDark) {
                                    null -> true
                                    true -> false
                                    false -> null
                                }
                            }
                        )
                    }
                }
            }

            // Scanner & PDF Defaults
            item {
                SettingsSectionHeader("Scanner & PDF Defaults")
            }
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.HighQuality,
                            title = "Default PDF Quality",
                            subtitle = defaultQuality.displayName,
                            onClick = { showQualityDialog = true }
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        SettingsRow(
                            icon = Icons.Default.AspectRatio,
                            title = "Default Page Size",
                            subtitle = defaultPageSize.displayName,
                            onClick = { showPageSizeDialog = true }
                        )
                    }
                }
            }

            // Storage & Cache
            item {
                SettingsSectionHeader("Storage & Data")
            }
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.Storage,
                            title = "Total Storage Used",
                            subtitle = viewModel.formatBytes(storageBytes ?: 0L),
                            showChevron = false
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        SettingsRow(
                            icon = Icons.Default.CleaningServices,
                            title = "Clear Cache & Temporary Files",
                            subtitle = "Free temporary processing space",
                            onClick = {
                                context.cacheDir.deleteRecursively()
                                context.cacheDir.mkdirs()
                                Toast.makeText(context, "Cache cleared successfully!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // Security & Privacy
            item {
                SettingsSectionHeader("Security & About")
            }
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsRow(
                            icon = Icons.Default.Security,
                            title = "Privacy & Data Protection",
                            subtitle = "100% On-Device Processing First",
                            onClick = { showPrivacyDialog = true }
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        SettingsRow(
                            icon = Icons.Default.Info,
                            title = "About NEO AI SCANNER PRO",
                            subtitle = "v1.0 • Professional Mobile Suite",
                            onClick = { showAboutDialog = true }
                        )
                    }
                }
            }
        }
    }

    // Quality Selector Dialog
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Select PDF Quality") },
            text = {
                Column {
                    PdfQuality.entries.forEach { q ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.defaultPdfQuality.value = q
                                    showQualityDialog = false
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            RadioButton(selected = defaultQuality == q, onClick = null)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(q.displayName)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Close") }
            }
        )
    }

    // Page Size Dialog
    if (showPageSizeDialog) {
        AlertDialog(
            onDismissRequest = { showPageSizeDialog = false },
            title = { Text("Default Page Size") },
            text = {
                Column {
                    listOf(DocPageSize.A4, DocPageSize.LETTER, DocPageSize.LEGAL, DocPageSize.AUTO).forEach { size ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.defaultPageSize.value = size
                                    showPageSizeDialog = false
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            RadioButton(selected = defaultPageSize == size, onClick = null)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(size.displayName)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPageSizeDialog = false }) { Text("Close") }
            }
        )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy & On-Device Security") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "• 100% On-Device Operations: Your documents, camera scans, signatures, and PDFs are created, transformed, and stored exclusively on your device.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• No Cloud Retention: Scans are never uploaded to remote servers without your explicit action.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• Encrypted File Access: Built with standard Android application sandbox security.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showPrivacyDialog = false }) { Text("Got it") }
            }
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("NEO AI SCANNER PRO") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Version 1.0.0 (Production Build)", fontWeight = FontWeight.Bold)
                    Text("An enterprise-grade document scanner, PDF converter, and optical character recognition workstation.")
                    Text("Featuring real CameraX scanning, edge detection, native PdfRenderer & PdfDocument engines, and Gemini Multimodal AI.")
                }
            },
            confirmButton = {
                Button(onClick = { showAboutDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
fun SettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    showChevron: Boolean = true
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (showChevron && onClick != null) {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}
