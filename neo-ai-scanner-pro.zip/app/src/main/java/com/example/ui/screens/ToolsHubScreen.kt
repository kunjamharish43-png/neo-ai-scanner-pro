package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.NeoTopBar
import com.example.ui.theme.*
import com.example.viewmodel.ScannerViewModel
import com.example.viewmodel.ToolType

data class ToolDefinition(
    val type: ToolType,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun ToolsHubScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val pdfConversionTools = listOf(
        ToolDefinition(ToolType.PDF_TO_JPG, Icons.Default.Image, PrimaryBlue),
        ToolDefinition(ToolType.JPG_TO_PDF, Icons.Default.PictureAsPdf, AccentCyan)
    )

    val pdfManagementTools = listOf(
        ToolDefinition(ToolType.MERGE_PDF, Icons.Default.MergeType, Color(0xFF6366F1)),
        ToolDefinition(ToolType.SPLIT_PDF, Icons.Default.CallSplit, Color(0xFFEC4899)),
        ToolDefinition(ToolType.COMPRESS_PDF, Icons.Default.Compress, Color(0xFF10B981)),
        ToolDefinition(ToolType.ROTATE_PDF, Icons.Default.RotateRight, Color(0xFFF59E0B)),
        ToolDefinition(ToolType.REORDER_PAGES, Icons.Default.Reorder, Color(0xFF0EA5E9)),
        ToolDefinition(ToolType.DELETE_PAGES, Icons.Default.DeleteSweep, DangerRed)
    )

    val securityTools = listOf(
        ToolDefinition(ToolType.PROTECT_PDF, Icons.Default.Lock, DeepNavy700),
        ToolDefinition(ToolType.UNLOCK_PDF, Icons.Default.LockOpen, SuccessGreen),
        ToolDefinition(ToolType.SIGNATURE, Icons.Default.Draw, PurpleAccent),
        ToolDefinition(ToolType.WATERMARK, Icons.Default.BrandingWatermark, Color(0xFF0284C7))
    )

    val aiAndScannerTools = listOf(
        ToolDefinition(ToolType.SCAN_DOCUMENT, Icons.Default.DocumentScanner, PrimaryBlue),
        ToolDefinition(ToolType.AI_OCR, Icons.Default.TextFields, Color(0xFFF59E0B)),
        ToolDefinition(ToolType.ENHANCER, Icons.Default.AutoFixHigh, Color(0xFF06B6D4)),
        ToolDefinition(ToolType.QR_BARCODE, Icons.Default.QrCodeScanner, Color(0xFF10B981))
    )

    Scaffold(
        topBar = {
            NeoTopBar(title = "All PDF & AI Tools")
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.testTag("tools_hub_screen")
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // AI & Smart Scanning Category
            item {
                ToolSectionHeader("AI Scanning & Smart OCR", "Camera capture, text extraction, and cleanup")
            }
            items(aiAndScannerTools.size) { idx ->
                val tool = aiAndScannerTools[idx]
                ToolItemRow(tool = tool, onClick = { viewModel.openTool(tool.type) })
            }

            // PDF Conversion Category
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ToolSectionHeader("PDF Conversion", "Convert documents between PDF and high-res images")
            }
            items(pdfConversionTools.size) { idx ->
                val tool = pdfConversionTools[idx]
                ToolItemRow(tool = tool, onClick = { viewModel.openTool(tool.type) })
            }

            // Advanced PDF Tools Category
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ToolSectionHeader("PDF Editing & Pages", "Organize, merge, split, rotate, and compress files")
            }
            items(pdfManagementTools.size) { idx ->
                val tool = pdfManagementTools[idx]
                ToolItemRow(tool = tool, onClick = { viewModel.openTool(tool.type) })
            }

            // Security & Signatures Category
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ToolSectionHeader("Security & Signatures", "Password protection, digital signatures, and watermarks")
            }
            items(securityTools.size) { idx ->
                val tool = securityTools[idx]
                ToolItemRow(tool = tool, onClick = { viewModel.openTool(tool.type) })
            }
        }
    }
}

@Composable
fun ToolSectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ToolItemRow(
    tool: ToolDefinition,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("tool_row_${tool.type.name.lowercase()}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(tool.color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.type.title,
                    tint = tool.color,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tool.type.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = tool.type.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}
