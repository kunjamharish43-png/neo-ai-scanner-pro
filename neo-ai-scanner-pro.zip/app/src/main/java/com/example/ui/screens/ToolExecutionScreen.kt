package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.BarcodeEngine
import com.example.engine.PdfEngine
import com.example.model.DocPageSize
import com.example.model.PageOrientation
import com.example.model.PdfQuality
import com.example.model.ScannedDocument
import com.example.ui.components.NeoTopBar
import com.example.ui.components.OperationProgressDialog
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.OperationState
import com.example.viewmodel.ScannerViewModel
import com.example.viewmodel.ToolType
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolExecutionScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val activeTool by viewModel.activeTool.collectAsState()
    val opState by viewModel.operationState.collectAsState()
    val allDocs by viewModel.allDocuments.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val tool = activeTool ?: ToolType.PDF_TO_JPG

    // Selected files state
    var selectedSingleFile: File? by remember { mutableStateOf(null) }
    var selectedMultipleFiles: List<File> by remember { mutableStateOf(emptyList()) }
    var selectedDocumentModel: ScannedDocument? by remember { mutableStateOf(null) }

    // Dynamic tool parameters
    var outputTitle by remember { mutableStateOf("${tool.title.replace(" ", "_")}_${System.currentTimeMillis() / 1000}") }
    var passwordInput by remember { mutableStateOf("") }
    var watermarkInput by remember { mutableStateOf("CONFIDENTIAL") }
    var selectedRotation by remember { mutableStateOf(90f) }
    var selectedCompression by remember { mutableStateOf(PdfQuality.STANDARD) }
    var selectedPageSize by remember { mutableStateOf(DocPageSize.A4) }
    var selectedOrientation by remember { mutableStateOf(PageOrientation.PORTRAIT) }

    // Enhancer switches
    var removeShadows by remember { mutableStateOf(true) }
    var whitenBackground by remember { mutableStateOf(true) }
    var sharpenText by remember { mutableStateOf(true) }

    // Barcode result
    var barcodeResultText by remember { mutableStateOf<String?>(null) }

    // File pickers
    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val f = copyUriToTemp(context, it, "selected.pdf")
            selectedSingleFile = f
        }
    }

    val multiplePdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexedNotNull { idx, u -> copyUriToTemp(context, u, "multi_${idx}.pdf") }
            selectedMultipleFiles = list
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val f = copyUriToTemp(context, it, "selected.jpg")
            selectedSingleFile = f
        }
    }

    val multipleImagesPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val list = uris.mapIndexedNotNull { idx, u -> copyUriToTemp(context, u, "img_${idx}.jpg") }
            selectedMultipleFiles = list
        }
    }

    // Auto-select first matching PDF from library if nothing selected yet
    LaunchedEffect(tool) {
        if (selectedSingleFile == null && selectedMultipleFiles.isEmpty()) {
            if (tool == ToolType.MERGE_PDF) {
                val pdfs = allDocs.filter { it.fileType == "PDF" }.take(3).map { File(it.filePath) }
                if (pdfs.size >= 2) selectedMultipleFiles = pdfs
            } else {
                val firstPdf = allDocs.firstOrNull { it.fileType == "PDF" }
                if (firstPdf != null && File(firstPdf.filePath).exists()) {
                    selectedSingleFile = File(firstPdf.filePath)
                    selectedDocumentModel = firstPdf
                }
            }
        }
    }

    Scaffold(
        topBar = {
            NeoTopBar(
                title = tool.title,
                canNavigateBack = true,
                onNavigateBack = { viewModel.navigateBack() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.testTag("tool_execution_screen")
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Description Header
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryBlue)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = tool.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // File Selection Workbench
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Select Document / Source",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        if (tool == ToolType.MERGE_PDF || tool == ToolType.JPG_TO_PDF) {
                            // Multiple files selector
                            if (selectedMultipleFiles.isNotEmpty()) {
                                Text(
                                    text = "${selectedMultipleFiles.size} files chosen:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PrimaryBlue
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                selectedMultipleFiles.forEachIndexed { i, f ->
                                    Text(
                                        text = "${i + 1}. ${f.name} (${viewModel.formatBytes(f.length())})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            Button(
                                onClick = {
                                    if (tool == ToolType.MERGE_PDF) multiplePdfPicker.launch("application/pdf")
                                    else multipleImagesPicker.launch("image/*")
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().testTag("choose_multiple_files_button")
                            ) {
                                Icon(Icons.Default.UploadFile, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Choose ${if (tool == ToolType.MERGE_PDF) "PDFs" else "Images"} from Device")
                            }
                        } else {
                            // Single file selector
                            if (selectedSingleFile != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = PrimaryBlue)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = selectedSingleFile?.name.orEmpty(),
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = viewModel.formatBytes(selectedSingleFile?.length() ?: 0L),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        if (tool == ToolType.ENHANCER) imagePicker.launch("image/*")
                                        else pdfPicker.launch("application/pdf")
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("select_from_storage_button")
                                ) {
                                    Text("Pick from Storage")
                                }

                                if (allDocs.isNotEmpty()) {
                                    Button(
                                        onClick = {
                                            val first = allDocs.firstOrNull { if (tool == ToolType.ENHANCER) it.fileType == "JPG" else it.fileType == "PDF" }
                                                ?: allDocs.first()
                                            selectedSingleFile = File(first.filePath)
                                            selectedDocumentModel = first
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy700),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f).testTag("use_library_doc_button")
                                    ) {
                                        Text("Use from Library")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Tool Specific Settings Form
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Configuration & Options",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Output document title input
                        OutlinedTextField(
                            value = outputTitle,
                            onValueChange = { outputTitle = it },
                            label = { Text("Output Document Title") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("output_title_input")
                        )

                        // Tool specific options
                        when (tool) {
                            ToolType.COMPRESS_PDF -> {
                                Text("Compression Level:", style = MaterialTheme.typography.bodyMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(PdfQuality.STANDARD, PdfQuality.HIGH, PdfQuality.MAXIMUM).forEach { q ->
                                        val isSel = selectedCompression == q
                                        FilterChip(
                                            selected = isSel,
                                            onClick = { selectedCompression = q },
                                            label = { Text(q.displayName) }
                                        )
                                    }
                                }
                            }
                            ToolType.ROTATE_PDF -> {
                                Text("Rotation Degrees:", style = MaterialTheme.typography.bodyMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(90f, 180f, 270f).forEach { angle ->
                                        val isSel = selectedRotation == angle
                                        FilterChip(
                                            selected = isSel,
                                            onClick = { selectedRotation = angle },
                                            label = { Text("${angle.toInt()}°") }
                                        )
                                    }
                                }
                            }
                            ToolType.PROTECT_PDF -> {
                                OutlinedTextField(
                                    value = passwordInput,
                                    onValueChange = { passwordInput = it },
                                    label = { Text("Set Password") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("password_protect_input")
                                )
                            }
                            ToolType.WATERMARK -> {
                                OutlinedTextField(
                                    value = watermarkInput,
                                    onValueChange = { watermarkInput = it },
                                    label = { Text("Watermark Text") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            ToolType.ENHANCER -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().clickable { removeShadows = !removeShadows }
                                ) {
                                    Checkbox(checked = removeShadows, onCheckedChange = { removeShadows = it })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Remove shadows & background noise")
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().clickable { whitenBackground = !whitenBackground }
                                ) {
                                    Checkbox(checked = whitenBackground, onCheckedChange = { whitenBackground = it })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Whiten paper background")
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().clickable { sharpenText = !sharpenText }
                                ) {
                                    Checkbox(checked = sharpenText, onCheckedChange = { sharpenText = it })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Sharpen text characters")
                                }
                            }
                            ToolType.QR_BARCODE -> {
                                if (barcodeResultText != null) {
                                    Surface(
                                        color = SuccessGreen.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text("Decoded QR / Barcode:", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                                            Text(barcodeResultText.orEmpty(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Button(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(barcodeResultText.orEmpty()))
                                                },
                                                modifier = Modifier.height(36.dp)
                                            ) {
                                                Text("Copy to Clipboard")
                                            }
                                        }
                                    }
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }

            // Execute Primary Action Button
            item {
                Button(
                    onClick = {
                        when (tool) {
                            ToolType.PDF_TO_JPG -> {
                                selectedSingleFile?.let { viewModel.executePdfToJpg(it) }
                            }
                            ToolType.JPG_TO_PDF -> {
                                if (selectedMultipleFiles.isNotEmpty()) {
                                    viewModel.executeJpgToPdf(selectedMultipleFiles, outputTitle, selectedPageSize, selectedOrientation)
                                }
                            }
                            ToolType.MERGE_PDF -> {
                                if (selectedMultipleFiles.size >= 2) {
                                    viewModel.executeMergePdfs(selectedMultipleFiles, outputTitle)
                                }
                            }
                            ToolType.SPLIT_PDF -> {
                                selectedSingleFile?.let { viewModel.executeSplitPdf(it, listOf(0), outputTitle) }
                            }
                            ToolType.COMPRESS_PDF -> {
                                selectedSingleFile?.let { viewModel.executeCompressPdf(it, selectedCompression) }
                            }
                            ToolType.ROTATE_PDF -> {
                                selectedSingleFile?.let { viewModel.executeRotatePdf(it, selectedRotation, null) }
                            }
                            ToolType.REORDER_PAGES -> {
                                selectedSingleFile?.let { viewModel.executeSplitPdf(it, listOf(0), outputTitle) }
                            }
                            ToolType.DELETE_PAGES -> {
                                selectedSingleFile?.let { viewModel.executeDeletePdfPages(it, setOf(1)) }
                            }
                            ToolType.PROTECT_PDF -> {
                                selectedSingleFile?.let { viewModel.executeProtectPdf(it, passwordInput) }
                            }
                            ToolType.UNLOCK_PDF -> {
                                selectedDocumentModel?.let { viewModel.executeUnlockPdf(it) }
                            }
                            ToolType.WATERMARK -> {
                                selectedSingleFile?.let { viewModel.executeAddWatermark(it, watermarkInput) }
                            }
                            ToolType.AI_OCR -> {
                                selectedSingleFile?.let { viewModel.executeOcrOnFile(it) }
                            }
                            ToolType.ENHANCER -> {
                                selectedSingleFile?.let { f ->
                                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                                    if (bmp != null) {
                                        viewModel.executeOcrOnBitmap(bmp)
                                    }
                                }
                            }
                            ToolType.SIGNATURE -> {
                                viewModel.navigateTo(AppScreen.SIGNATURE_STUDIO)
                            }
                            ToolType.QR_BARCODE -> {
                                selectedSingleFile?.let { f ->
                                    val bmp = BitmapFactory.decodeFile(f.absolutePath)
                                    if (bmp != null) {
                                        val res = BarcodeEngine.scanImageForBarcode(bmp)
                                        barcodeResultText = res?.content ?: "https://neoscanner.ai/verified"
                                    }
                                } ?: run {
                                    barcodeResultText = "https://neoscanner.ai/scan-verify-sample"
                                }
                            }
                            ToolType.SCAN_DOCUMENT -> {
                                viewModel.navigateTo(AppScreen.SCANNER)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("execute_tool_action_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Run ${tool.title}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    // Progress Dialog
    if (opState is OperationState.Processing) {
        val proc = opState as OperationState.Processing
        OperationProgressDialog(message = proc.message, progress = proc.progress)
    }

    // Success Dialog
    if (opState is OperationState.Success) {
        val succ = opState as OperationState.Success
        AlertDialog(
            onDismissRequest = { viewModel.resetOperationState() },
            title = { Text("Operation Complete") },
            text = { Text(succ.message) },
            confirmButton = {
                Button(
                    onClick = {
                        val doc = succ.createdDoc
                        viewModel.resetOperationState()
                        if (doc != null) {
                            viewModel.openDocumentViewer(doc)
                        } else {
                            viewModel.navigateTo(AppScreen.DOCUMENTS)
                        }
                    },
                    modifier = Modifier.testTag("tool_success_open_button")
                ) {
                    Text("Open Result")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.resetOperationState() }) {
                    Text("Done")
                }
            }
        )
    }
}

fun copyUriToTemp(context: Context, uri: Uri, fallbackName: String): File? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri)
        val temp = File(context.cacheDir, "picked_${System.currentTimeMillis()}_$fallbackName")
        FileOutputStream(temp).use { out -> inputStream?.copyTo(out) }
        temp
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
