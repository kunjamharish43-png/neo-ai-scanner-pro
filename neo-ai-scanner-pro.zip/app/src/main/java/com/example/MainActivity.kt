package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomNavBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.ScannerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ScannerViewModel = viewModel()
            val darkModeSetting by viewModel.darkMode.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()

            val isDark = darkModeSetting ?: isSystemInDarkTheme()

            MyApplicationTheme(darkTheme = isDark) {
                // Handle physical & predictive back button
                BackHandler(enabled = currentScreen != AppScreen.HOME) {
                    viewModel.navigateBack()
                }

                val showBottomBar = currentScreen in setOf(
                    AppScreen.HOME,
                    AppScreen.TOOLS,
                    AppScreen.DOCUMENTS,
                    AppScreen.SETTINGS
                )

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            BottomNavBar(
                                currentScreen = currentScreen,
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                        }
                    }
                ) { innerPadding ->
                    when (currentScreen) {
                        AppScreen.HOME -> HomeScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppScreen.SCANNER -> CameraScannerScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                        AppScreen.TOOLS -> ToolsHubScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppScreen.DOCUMENTS -> DocumentsScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppScreen.SETTINGS -> SettingsScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppScreen.TOOL_EXECUTION -> ToolExecutionScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                        AppScreen.PDF_VIEWER -> PdfViewerScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                        AppScreen.OCR_RESULT -> OcrResultScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                        AppScreen.SIGNATURE_STUDIO -> SignatureScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}
