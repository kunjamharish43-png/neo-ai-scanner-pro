package com.example.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.database.AppDatabase
import com.example.engine.ImageProcessor
import com.example.engine.PdfEngine
import com.example.model.ScannedDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DocumentRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val dao = db.documentDao()

    val allDocuments: Flow<List<ScannedDocument>> = dao.getAllDocuments()
    val favoriteDocuments: Flow<List<ScannedDocument>> = dao.getFavoriteDocuments()
    val allFolders: Flow<List<String>> = dao.getAllFolders()
    val documentCount: Flow<Int> = dao.getDocumentCount()
    val totalStorageBytes: Flow<Long?> = dao.getTotalStorageBytes()

    fun getDocumentsByFolder(folder: String): Flow<List<ScannedDocument>> {
        return if (folder == "All" || folder.isBlank()) {
            dao.getAllDocuments()
        } else if (folder == "Favorites") {
            dao.getFavoriteDocuments()
        } else {
            dao.getDocumentsByFolder(folder)
        }
    }

    fun searchDocuments(query: String): Flow<List<ScannedDocument>> = dao.searchDocuments(query)

    suspend fun getDocumentById(id: Long): ScannedDocument? = withContext(Dispatchers.IO) {
        dao.getDocumentById(id)
    }

    suspend fun insertDocument(doc: ScannedDocument): Long = withContext(Dispatchers.IO) {
        dao.insertDocument(doc)
    }

    suspend fun updateDocument(doc: ScannedDocument) = withContext(Dispatchers.IO) {
        dao.updateDocument(doc.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun toggleFavorite(doc: ScannedDocument) = withContext(Dispatchers.IO) {
        dao.updateDocument(doc.copy(isFavorite = !doc.isFavorite, updatedAt = System.currentTimeMillis()))
    }

    suspend fun renameDocument(doc: ScannedDocument, newTitle: String) = withContext(Dispatchers.IO) {
        dao.updateDocument(doc.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
    }

    suspend fun moveDocumentToFolder(doc: ScannedDocument, folder: String) = withContext(Dispatchers.IO) {
        dao.updateDocument(doc.copy(folder = folder, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteDocument(doc: ScannedDocument) = withContext(Dispatchers.IO) {
        try {
            val file = File(doc.filePath)
            if (file.exists()) file.delete()
            doc.thumbnailPath?.let {
                val thumb = File(it)
                if (thumb.exists()) thumb.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        dao.deleteDocument(doc)
    }

    fun getDocumentsDir(): File {
        val dir = File(context.filesDir, "neo_documents")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getTempDir(): File {
        val dir = File(context.cacheDir, "neo_temp")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getThumbnailsDir(): File {
        val dir = File(context.filesDir, "neo_thumbnails")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Creates thumbnail from page 1 of PDF or image and saves to disk.
     */
    suspend fun generateThumbnail(sourceFile: File): String? = withContext(Dispatchers.IO) {
        try {
            val thumbFile = File(getThumbnailsDir(), "thumb_${System.currentTimeMillis()}.jpg")
            if (sourceFile.extension.equals("pdf", ignoreCase = true)) {
                val bitmaps = PdfEngine.pdfToBitmaps(sourceFile, maxPages = 1, scale = 0.5f)
                if (bitmaps.isNotEmpty()) {
                    val bmp = bitmaps[0]
                    ImageProcessor.saveBitmap(bmp, thumbFile, Bitmap.CompressFormat.JPEG, 75)
                    bmp.recycle()
                    return@withContext thumbFile.absolutePath
                }
            } else {
                val bmp = BitmapFactory.decodeFile(sourceFile.absolutePath)
                if (bmp != null) {
                    val scale = 300f / bmp.width.coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(bmp, 300, (bmp.height * scale).toInt().coerceAtLeast(300), true)
                    ImageProcessor.saveBitmap(scaled, thumbFile, Bitmap.CompressFormat.JPEG, 75)
                    scaled.recycle()
                    bmp.recycle()
                    return@withContext thumbFile.absolutePath
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext null
    }

    /**
     * Seeds initial demo guide documents so the library and dashboard look alive on first launch.
     */
    suspend fun seedInitialGuideDocIfNeeded() = withContext(Dispatchers.IO) {
        val dir = getDocumentsDir()
        val samplePdf = File(dir, "NEO_Scanner_Welcome_Guide.pdf")
        if (!samplePdf.exists()) {
            val tempImg = File(getTempDir(), "guide_page.jpg")
            // Generate clean welcome guide bitmap
            val bmp = Bitmap.createBitmap(800, 1100, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            canvas.drawColor(android.graphics.Color.WHITE)

            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#0A1E3F")
                textSize = 36f
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            }
            canvas.drawText("NEO AI SCANNER PRO", 60f, 120f, p)

            p.color = android.graphics.Color.parseColor("#0066FF")
            p.textSize = 22f
            canvas.drawText("Quick Start Guide & Welcome Document", 60f, 170f, p)

            p.color = android.graphics.Color.parseColor("#475569")
            p.textSize = 18f
            p.typeface = android.graphics.Typeface.DEFAULT
            val lines = listOf(
                "Welcome to NEO AI SCANNER PRO, your complete all-in-one",
                "document workstation and PDF transformation studio.",
                "",
                "Features available directly on device:",
                "• Camera Scanning with automatic edge detection & filters",
                "• PDF to JPG and JPG to PDF conversion",
                "• Merge, Split, Compress, Rotate & Reorder pages",
                "• Digital Signature signing and Watermarking",
                "• Smart AI OCR with Devanagari (Hindi) and English support",
                "• Document categorization, entity extraction & AI summaries"
            )
            var y = 230f
            for (line in lines) {
                canvas.drawText(line, 60f, y, p)
                y += 32f
            }

            ImageProcessor.saveBitmap(bmp, tempImg, Bitmap.CompressFormat.JPEG, 90)
            PdfEngine.createPdfFromImages(listOf(tempImg.absolutePath), samplePdf)
            val thumb = generateThumbnail(samplePdf)

            dao.insertDocument(
                ScannedDocument(
                    title = "NEO Scanner Welcome Guide",
                    filePath = samplePdf.absolutePath,
                    fileType = "PDF",
                    fileSizeBytes = samplePdf.length(),
                    pageCount = 1,
                    folder = "General",
                    tags = "Guide, Welcome, PDF",
                    thumbnailPath = thumb,
                    isFavorite = true,
                    ocrText = "Welcome to NEO AI SCANNER PRO, your complete all-in-one document workstation."
                )
            )
            bmp.recycle()
        }
    }
}
