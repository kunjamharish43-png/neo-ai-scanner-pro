package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scanned_documents")
data class ScannedDocument(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val filePath: String,
    val fileType: String = "PDF", // "PDF", "JPG", "TXT"
    val fileSizeBytes: Long = 0,
    val pageCount: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val folder: String = "All",
    val tags: String = "",
    val thumbnailPath: String? = null,
    val isFavorite: Boolean = false,
    val ocrText: String? = null,
    val isProtected: Boolean = false
)

data class ScanPage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val imagePath: String,
    val rotationDegrees: Int = 0,
    val filterType: FilterType = FilterType.ORIGINAL
)

enum class FilterType(val displayName: String) {
    ORIGINAL("Original"),
    MAGIC_COLOR("Magic Color"),
    GRAYSCALE("Grayscale"),
    BLACK_WHITE("B&W Clean"),
    SHARPEN("Sharpened"),
    PHOTO("Photo Enhance")
}

enum class DocPageSize(val displayName: String, val widthPt: Int, val heightPt: Int) {
    A4("A4 (210 × 297 mm)", 595, 842),
    LETTER("Letter (8.5 × 11 in)", 612, 792),
    LEGAL("Legal (8.5 × 14 in)", 612, 1008),
    A3("A3 (297 × 420 mm)", 842, 1191),
    AUTO("Auto (Fit Content)", 0, 0)
}

enum class PageOrientation(val displayName: String) {
    PORTRAIT("Portrait"),
    LANDSCAPE("Landscape")
}

enum class PdfQuality(val displayName: String, val scaleFactor: Float, val compressQuality: Int) {
    STANDARD("Standard (Fast)", 0.75f, 75),
    HIGH("High Quality (Balanced)", 1.0f, 85),
    MAXIMUM("Maximum (Crisp)", 1.25f, 95)
}

data class OcrAnalysisResult(
    val rawText: String,
    val docType: String = "Standard Document", // Invoice, Receipt, ID Card, Note, etc.
    val summary: String = "",
    val fields: Map<String, String> = emptyMap(),
    val detectedLanguage: String = "English",
    val cleanedText: String = rawText
)
