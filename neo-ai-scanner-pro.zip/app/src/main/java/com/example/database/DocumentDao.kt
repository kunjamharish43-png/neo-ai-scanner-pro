package com.example.database

import androidx.room.*
import com.example.model.ScannedDocument
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Query("SELECT * FROM scanned_documents ORDER BY createdAt DESC")
    fun getAllDocuments(): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavoriteDocuments(): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE folder = :folderName ORDER BY createdAt DESC")
    fun getDocumentsByFolder(folderName: String): Flow<List<ScannedDocument>>

    @Query("SELECT * FROM scanned_documents WHERE id = :id LIMIT 1")
    suspend fun getDocumentById(id: Long): ScannedDocument?

    @Query("SELECT DISTINCT folder FROM scanned_documents WHERE folder != ''")
    fun getAllFolders(): Flow<List<String>>

    @Query("SELECT * FROM scanned_documents WHERE title LIKE '%' || :query || '%' OR ocrText LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchDocuments(query: String): Flow<List<ScannedDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: ScannedDocument): Long

    @Update
    suspend fun updateDocument(document: ScannedDocument)

    @Delete
    suspend fun deleteDocument(document: ScannedDocument)

    @Query("DELETE FROM scanned_documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)

    @Query("SELECT COUNT(*) FROM scanned_documents")
    fun getDocumentCount(): Flow<Int>

    @Query("SELECT SUM(fileSizeBytes) FROM scanned_documents")
    fun getTotalStorageBytes(): Flow<Long?>
}
