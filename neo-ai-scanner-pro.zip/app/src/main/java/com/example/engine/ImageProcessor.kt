package com.example.engine

import android.graphics.*
import com.example.model.FilterType
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object ImageProcessor {

    fun applyFilter(source: Bitmap, filterType: FilterType): Bitmap {
        return when (filterType) {
            FilterType.ORIGINAL -> source.copy(source.config ?: Bitmap.Config.ARGB_8888, true)
            FilterType.MAGIC_COLOR -> applyMagicColor(source)
            FilterType.GRAYSCALE -> applyGrayscale(source)
            FilterType.BLACK_WHITE -> applyBlackAndWhiteThreshold(source)
            FilterType.SHARPEN -> applySharpen(source)
            FilterType.PHOTO -> applyPhotoEnhancement(source)
        }
    }

    fun rotateBitmap(source: Bitmap, degrees: Float): Bitmap {
        if (degrees % 360f == 0f) return source
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    fun cropBitmap(source: Bitmap, leftFraction: Float, topFraction: Float, rightFraction: Float, bottomFraction: Float): Bitmap {
        val l = (max(0f, min(1f, leftFraction)) * source.width).toInt()
        val t = (max(0f, min(1f, topFraction)) * source.height).toInt()
        val r = (max(0f, min(1f, rightFraction)) * source.width).toInt()
        val b = (max(0f, min(1f, bottomFraction)) * source.height).toInt()

        val width = max(10, r - l)
        val height = max(10, b - t)
        val safeWidth = min(width, source.width - l)
        val safeHeight = min(height, source.height - t)

        return Bitmap.createBitmap(source, l, t, safeWidth, safeHeight)
    }

    /**
     * Magic Color filter: Normalizes paper background to clean white and boosts ink contrast.
     */
    private fun applyMagicColor(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Color matrix with contrast and saturation boost + slight brightness
        val contrast = 1.35f
        val brightness = 15f
        val cm = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            )
        )
        // Boost saturation slightly
        val satMatrix = ColorMatrix()
        satMatrix.setSaturation(1.2f)
        cm.postConcat(satMatrix)

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    /**
     * Grayscale filter
     */
    private fun applyGrayscale(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    /**
     * B&W Clean Threshold: Whitens grayish background paper and forces text to crisp dark.
     */
    private fun applyBlackAndWhiteThreshold(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        // Compute average luminance to determine adaptive threshold
        var totalLum = 0L
        for (i in pixels.indices) {
            val color = pixels[i]
            val r = (color shr 16) and 0xFF
            val g = (color shr 8) and 0xFF
            val b = color and 0xFF
            val lum = (r * 299 + g * 587 + b * 114) / 1000
            totalLum += lum
        }
        val avgLum = (totalLum / pixels.size).toInt()
        val threshold = max(100, min(175, avgLum - 10))

        for (i in pixels.indices) {
            val color = pixels[i]
            val r = (color shr 16) and 0xFF
            val g = (color shr 8) and 0xFF
            val b = color and 0xFF
            val lum = (r * 299 + g * 587 + b * 114) / 1000

            // If above threshold -> white paper, if below -> crisp black text
            pixels[i] = if (lum > threshold) {
                Color.WHITE
            } else {
                Color.BLACK
            }
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }

    /**
     * Sharpening algorithm using edge convolution
     */
    private fun applySharpen(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)
        val resultPixels = pixels.clone()

        // 3x3 sharpen kernel:
        //  0 -1  0
        // -1  5 -1
        //  0 -1  0
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x

                val cTop = pixels[(y - 1) * width + x]
                val cBottom = pixels[(y + 1) * width + x]
                val cLeft = pixels[y * width + (x - 1)]
                val cRight = pixels[y * width + (x + 1)]
                val cCenter = pixels[idx]

                var r = (5 * ((cCenter shr 16) and 0xFF)) -
                        (((cTop shr 16) and 0xFF) + ((cBottom shr 16) and 0xFF) + ((cLeft shr 16) and 0xFF) + ((cRight shr 16) and 0xFF))
                var g = (5 * ((cCenter shr 8) and 0xFF)) -
                        (((cTop shr 8) and 0xFF) + ((cBottom shr 8) and 0xFF) + ((cLeft shr 8) and 0xFF) + ((cRight shr 8) and 0xFF))
                var b = (5 * (cCenter and 0xFF)) -
                        ((cTop and 0xFF) + (cBottom and 0xFF) + (cLeft and 0xFF) + (cRight and 0xFF))

                r = max(0, min(255, r))
                g = max(0, min(255, g))
                b = max(0, min(255, b))

                resultPixels[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        output.setPixels(resultPixels, 0, width, 0, 0, width, height)
        return output
    }

    private fun applyPhotoEnhancement(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val cm = ColorMatrix(
            floatArrayOf(
                1.15f, 0f, 0f, 0f, 10f,
                0f, 1.15f, 0f, 0f, 10f,
                0f, 0f, 1.15f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val sat = ColorMatrix()
        sat.setSaturation(1.15f)
        cm.postConcat(sat)

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    /**
     * Complete Document Enhancer tool with shadow removal, whitening, sharpening, contrast, and brightness
     */
    fun enhanceDocument(
        source: Bitmap,
        removeShadows: Boolean,
        whitenBackground: Boolean,
        sharpenText: Boolean,
        contrastMultiplier: Float, // 1.0f default
        brightnessAdd: Float       // 0f default
    ): Bitmap {
        var current = source

        if (removeShadows || whitenBackground) {
            val width = current.width
            val height = current.height
            val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(width * height)
            current.getPixels(pixels, 0, width, 0, 0, width, height)

            for (i in pixels.indices) {
                val color = pixels[i]
                var r = (color shr 16) and 0xFF
                var g = (color shr 8) and 0xFF
                var b = color and 0xFF

                val lum = (r * 299 + g * 587 + b * 114) / 1000

                // If bright enough (paper background), push towards pure white
                if (whitenBackground && lum > 165) {
                    r = min(255, (r * 1.25f).toInt())
                    g = min(255, (g * 1.25f).toInt())
                    b = min(255, (b * 1.25f).toInt())
                } else if (removeShadows && lum in 120..165) {
                    // Shadow compensation
                    r = min(255, (r + 35))
                    g = min(255, (g + 35))
                    b = min(255, (b + 35))
                }

                pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            output.setPixels(pixels, 0, width, 0, 0, width, height)
            current = output
        }

        if (contrastMultiplier != 1.0f || brightnessAdd != 0f) {
            val output = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val cm = ColorMatrix(
                floatArrayOf(
                    contrastMultiplier, 0f, 0f, 0f, brightnessAdd,
                    0f, contrastMultiplier, 0f, 0f, brightnessAdd,
                    0f, 0f, contrastMultiplier, 0f, brightnessAdd,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            paint.colorFilter = ColorMatrixColorFilter(cm)
            canvas.drawBitmap(current, 0f, 0f, paint)
            current = output
        }

        if (sharpenText) {
            current = applySharpen(current)
        }

        return current
    }

    fun saveBitmap(bitmap: Bitmap, targetFile: File, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 90): Boolean {
        return try {
            targetFile.parentFile?.mkdirs()
            FileOutputStream(targetFile).use { out ->
                bitmap.compress(format, quality, out)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
