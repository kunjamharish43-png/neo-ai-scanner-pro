package com.example.engine

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.model.DocPageSize
import com.example.model.PageOrientation
import com.example.model.PdfQuality
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

object PdfEngine {

    /**
     * Converts a list of image file paths into a real multi-page PDF.
     */
    fun createPdfFromImages(
        imagePaths: List<String>,
        outputFile: File,
        pageSize: DocPageSize = DocPageSize.A4,
        orientation: PageOrientation = PageOrientation.PORTRAIT,
        quality: PdfQuality = PdfQuality.HIGH,
        marginDp: Int = 0,
        watermarkText: String? = null,
        watermarkOpacity: Float = 0.25f,
        signatureBitmap: Bitmap? = null,
        signatureRectF: RectF? = null,
        addPageNumbers: Boolean = false
    ): Boolean {
        if (imagePaths.isEmpty()) return false
        val pdfDocument = PdfDocument()

        try {
            val totalPages = imagePaths.size

            for (index in imagePaths.indices) {
                val path = imagePaths[index]
                val bitmap = BitmapFactory.decodeFile(path) ?: continue

                // Determine base page dimensions
                var targetWidth: Int
                var targetHeight: Int

                if (pageSize == DocPageSize.AUTO) {
                    targetWidth = (bitmap.width * quality.scaleFactor).toInt().coerceAtLeast(300)
                    targetHeight = (bitmap.height * quality.scaleFactor).toInt().coerceAtLeast(400)
                } else {
                    targetWidth = pageSize.widthPt
                    targetHeight = pageSize.heightPt
                }

                if (orientation == PageOrientation.LANDSCAPE && targetWidth < targetHeight) {
                    val temp = targetWidth
                    targetWidth = targetHeight
                    targetHeight = temp
                } else if (orientation == PageOrientation.PORTRAIT && targetWidth > targetHeight) {
                    val temp = targetWidth
                    targetWidth = targetHeight
                    targetHeight = temp
                }

                val pageInfo = PdfDocument.PageInfo.Builder(targetWidth, targetHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                // Background
                canvas.drawColor(Color.WHITE)

                // Calculate image bounds with margins
                val marginPx = marginDp.toFloat()
                val availW = targetWidth - (marginPx * 2)
                val availH = targetHeight - (marginPx * 2) - if (addPageNumbers) 30f else 0f

                val imgRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
                val canvasRatio = availW / availH

                var drawW = availW
                var drawH = availH
                var drawX = marginPx
                var drawY = marginPx

                if (imgRatio > canvasRatio) {
                    drawH = availW / imgRatio
                    drawY = marginPx + (availH - drawH) / 2f
                } else {
                    drawW = availH * imgRatio
                    drawX = marginPx + (availW - drawW) / 2f
                }

                val destRect = RectF(drawX, drawY, drawX + drawW, drawY + drawH)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                canvas.drawBitmap(bitmap, null, destRect, paint)

                // Draw Watermark if present
                if (!watermarkText.isNullOrBlank()) {
                    val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.DKGRAY
                        alpha = (watermarkOpacity * 255).toInt().coerceIn(20, 200)
                        textSize = (targetWidth / 10f).coerceAtLeast(24f)
                        textAlign = Paint.Align.CENTER
                        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    }
                    canvas.save()
                    canvas.rotate(-45f, targetWidth / 2f, targetHeight / 2f)
                    canvas.drawText(watermarkText, targetWidth / 2f, targetHeight / 2f, wmPaint)
                    canvas.restore()
                }

                // Draw Signature on current page if specified
                if (signatureBitmap != null && signatureRectF != null) {
                    val sigPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    canvas.drawBitmap(signatureBitmap, null, signatureRectF, sigPaint)
                }

                // Draw Page Numbering
                if (addPageNumbers) {
                    val pageText = "${index + 1} / $totalPages"
                    val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.DKGRAY
                        textSize = 12f
                        textAlign = Paint.Align.CENTER
                    }
                    canvas.drawText(pageText, targetWidth / 2f, targetHeight - 12f, numPaint)
                }

                pdfDocument.finishPage(page)
                bitmap.recycle()
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { out ->
                pdfDocument.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            pdfDocument.close()
        }
    }

    /**
     * Renders every page of a PDF file to a list of Bitmaps.
     */
    fun pdfToBitmaps(pdfFile: File, maxPages: Int = 100, scale: Float = 1.5f): List<Bitmap> {
        val bitmaps = mutableListOf<Bitmap>()
        if (!pdfFile.exists()) return bitmaps

        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val count = min(renderer.pageCount, maxPages)

            for (i in 0 until count) {
                val page = renderer.openPage(i)
                val width = (page.width * scale).toInt().coerceAtLeast(200)
                val height = (page.height * scale).toInt().coerceAtLeast(200)

                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE)

                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmaps.add(bitmap)
                page.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { renderer?.close() } catch (ignored: Exception) {}
            try { pfd?.close() } catch (ignored: Exception) {}
        }
        return bitmaps
    }

    /**
     * PDF TO JPG: Converts all pages to high-res JPG files.
     */
    fun convertPdfToJpg(pdfFile: File, outputDir: File, quality: Int = 90): List<File> {
        val createdFiles = mutableListOf<File>()
        outputDir.mkdirs()
        val bitmaps = pdfToBitmaps(pdfFile, scale = 2.0f)

        for (i in bitmaps.indices) {
            val bmp = bitmaps[i]
            val pageFile = File(outputDir, "${pdfFile.nameWithoutExtension}_page_${i + 1}.jpg")
            ImageProcessor.saveBitmap(bmp, pageFile, Bitmap.CompressFormat.JPEG, quality)
            createdFiles.add(pageFile)
            bmp.recycle()
        }
        return createdFiles
    }

    /**
     * Merge multiple PDF files into one combined PDF.
     */
    fun mergePdfs(pdfFiles: List<File>, outputFile: File): Boolean {
        if (pdfFiles.isEmpty()) return false
        val newPdf = PdfDocument()
        var globalPageIndex = 1

        try {
            for (file in pdfFiles) {
                var pfd: ParcelFileDescriptor? = null
                var renderer: PdfRenderer? = null
                try {
                    pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    renderer = PdfRenderer(pfd)

                    for (pageIdx in 0 until renderer.pageCount) {
                        val page = renderer.openPage(pageIdx)
                        val w = page.width
                        val h = page.height

                        val pageInfo = PdfDocument.PageInfo.Builder(w, h, globalPageIndex++).create()
                        val newPage = newPdf.startPage(pageInfo)
                        val canvas = newPage.canvas
                        canvas.drawColor(Color.WHITE)

                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        canvas.drawBitmap(bmp, 0f, 0f, null)

                        newPdf.finishPage(newPage)
                        page.close()
                        bmp.recycle()
                    }
                } finally {
                    try { renderer?.close() } catch (ignored: Exception) {}
                    try { pfd?.close() } catch (ignored: Exception) {}
                }
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { out ->
                newPdf.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            newPdf.close()
        }
    }

    /**
     * Split PDF by keeping only selected 0-indexed page indices.
     */
    fun splitOrExtractPages(inputPdf: File, outputFile: File, keepPageIndices: List<Int>): Boolean {
        if (!inputPdf.exists()) return false
        val newPdf = PdfDocument()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var newPageIndex = 1

        try {
            pfd = ParcelFileDescriptor.open(inputPdf, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            for (idx in keepPageIndices) {
                if (idx in 0 until renderer.pageCount) {
                    val page = renderer.openPage(idx)
                    val w = page.width
                    val h = page.height

                    val pageInfo = PdfDocument.PageInfo.Builder(w, h, newPageIndex++).create()
                    val newPage = newPdf.startPage(pageInfo)
                    newPage.canvas.drawColor(Color.WHITE)

                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    newPage.canvas.drawBitmap(bmp, 0f, 0f, null)

                    newPdf.finishPage(newPage)
                    page.close()
                    bmp.recycle()
                }
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { out ->
                newPdf.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            try { renderer?.close() } catch (ignored: Exception) {}
            try { pfd?.close() } catch (ignored: Exception) {}
            newPdf.close()
        }
    }

    /**
     * Rotate pages of PDF (all or specific set) by degrees.
     */
    fun rotatePdf(inputPdf: File, outputFile: File, degrees: Float, targetPages: Set<Int>? = null): Boolean {
        if (!inputPdf.exists()) return false
        val newPdf = PdfDocument()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var newPageIndex = 1

        try {
            pfd = ParcelFileDescriptor.open(inputPdf, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            for (idx in 0 until renderer.pageCount) {
                val shouldRotate = targetPages == null || targetPages.contains(idx)
                val angle = if (shouldRotate) degrees else 0f

                val page = renderer.openPage(idx)
                val originalW = page.width
                val originalH = page.height

                val is90Or270 = ((angle.toInt() % 360) + 360) % 180 != 0
                val targetW = if (is90Or270) originalH else originalW
                val targetH = if (is90Or270) originalW else originalH

                val pageInfo = PdfDocument.PageInfo.Builder(targetW, targetH, newPageIndex++).create()
                val newPage = newPdf.startPage(pageInfo)
                val canvas = newPage.canvas
                canvas.drawColor(Color.WHITE)

                val bmp = Bitmap.createBitmap(originalW, originalH, Bitmap.Config.ARGB_8888)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                if (angle != 0f) {
                    canvas.save()
                    canvas.translate(targetW / 2f, targetH / 2f)
                    canvas.rotate(angle)
                    canvas.translate(-originalW / 2f, -originalH / 2f)
                    canvas.drawBitmap(bmp, 0f, 0f, null)
                    canvas.restore()
                } else {
                    canvas.drawBitmap(bmp, 0f, 0f, null)
                }

                newPdf.finishPage(newPage)
                page.close()
                bmp.recycle()
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { out ->
                newPdf.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            try { renderer?.close() } catch (ignored: Exception) {}
            try { pfd?.close() } catch (ignored: Exception) {}
            newPdf.close()
        }
    }

    /**
     * Compress PDF by downsampling image resolutions and re-encoding.
     */
    fun compressPdf(inputPdf: File, outputFile: File, quality: PdfQuality = PdfQuality.STANDARD): Boolean {
        if (!inputPdf.exists()) return false
        val newPdf = PdfDocument()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var newPageIndex = 1

        try {
            pfd = ParcelFileDescriptor.open(inputPdf, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            for (idx in 0 until renderer.pageCount) {
                val page = renderer.openPage(idx)
                val w = (page.width * quality.scaleFactor).toInt().coerceAtLeast(300)
                val h = (page.height * quality.scaleFactor).toInt().coerceAtLeast(400)

                val pageInfo = PdfDocument.PageInfo.Builder(w, h, newPageIndex++).create()
                val newPage = newPdf.startPage(pageInfo)
                newPage.canvas.drawColor(Color.WHITE)

                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                newPage.canvas.drawBitmap(bmp, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), paint)

                newPdf.finishPage(newPage)
                page.close()
                bmp.recycle()
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { out ->
                newPdf.writeTo(out)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            try { renderer?.close() } catch (ignored: Exception) {}
            try { pfd?.close() } catch (ignored: Exception) {}
            newPdf.close()
        }
    }

    /**
     * Reorder pages in a PDF given an ordered list of 0-based page indices.
     */
    fun reorderPages(inputPdf: File, outputFile: File, newOrderIndices: List<Int>): Boolean {
        return splitOrExtractPages(inputPdf, outputFile, newOrderIndices)
    }

    /**
     * Delete pages from a PDF.
     */
    fun deletePages(inputPdf: File, outputFile: File, pagesToDelete: Set<Int>): Boolean {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(inputPdf, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val keepPages = (0 until renderer.pageCount).filterNot { pagesToDelete.contains(it) }
            if (keepPages.isEmpty()) return false
            return splitOrExtractPages(inputPdf, outputFile, keepPages)
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            try { renderer?.close() } catch (ignored: Exception) {}
            try { pfd?.close() } catch (ignored: Exception) {}
        }
    }

    /**
     * ZIP multiple files into a single zip archive.
     */
    fun zipFiles(files: List<File>, zipFile: File): Boolean {
        return try {
            zipFile.parentFile?.mkdirs()
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                val buffer = ByteArray(8192)
                for (file in files) {
                    if (!file.exists()) continue
                    val entry = ZipEntry(file.name)
                    zos.putNextEntry(entry)
                    FileInputStream(file).use { fis ->
                        var count: Int
                        while (fis.read(buffer).also { count = it } > 0) {
                            zos.write(buffer, 0, count)
                        }
                    }
                    zos.closeEntry()
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
